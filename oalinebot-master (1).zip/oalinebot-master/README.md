## For install Tutorial [HERE](https://www.youtube.com/watch?v=tffqvyI_K3A)
## Deploy to Heroku
#Ganti token dan chanel screet mu! di file app.py
```python
# Channel Access Token
line_bot_api = LineBotApi('ISI TOKEN OD KALIAN')
# Channel Secret
handler = WebhookHandler('ISI CHHANEL SCREET')
```

1. sudo apt-get install heroku
2. sudo pip install line-bot-sdk
3. sudo pip install flask
4. curl https://cli-assets.heroku.com/install-ubuntu.sh | sh
5. git clone https://github.com/Aditmadzs/oalinebot
6. EDIT TOKEN + SECRET DULU
7. Buka folder git kalian
```shell＝
cd oalinebot
```
8. Login Ke Heroku
```shell＝
heroku login
```
9. Buat aplikasi di heroku
```shell＝
heroku apps:create nama
```
10. Git Remote Ke Heroku
```shell＝
heroku git:remote nama 
```
11. Init ke git
```shell＝
git init
```
12. Tambahkan git
```shell
git add .
```
13. Lalu commit
```shell
git commit -m "Aditmadzs"
```
14. Push ke heroku
```shell
git push heroku master
```
15. Masukan Webhook URL
```shell
nama-aplikasi-di-heroku.herokuapp.com/callback
```
16. Tambahkan /callback dibelakang link webhook URL

17. Jalankan app.py
```shell
python3 app.py
```
#### TextSendMessage (text pesan)
```python
message = TextSendMessage(text='Hello, world')
line_bot_api.reply_message(event.reply_token, message)
```
#### ImageSendMessage (pesan gambar)
```python
message = ImageSendMessage(
    original_content_url='https://example.com/original.jpg',
    preview_image_url='https://example.com/preview.jpg'
)
line_bot_api.reply_message(event.reply_token, message)
```

#### VideoSendMessage (pesan video)
```python
message = VideoSendMessage(
    original_content_url='https://example.com/original.mp4',
    preview_image_url='https://example.com/preview.jpg'
)
line_bot_api.reply_message(event.reply_token, message)
```

#### AudioSendMessage (Pesan audio)
```python
message = AudioSendMessage(
    original_content_url='https://example.com/original.m4a',
    duration=240000
)
line_bot_api.reply_message(event.reply_token, message)
```
#### LocationSendMessage (pesan lokasi)
```python
message = LocationSendMessage(
    title='my location',
    address='Tokyo',
    latitude=35.65910807942215,
    longitude=139.70372892916203
)
line_bot_api.reply_message(event.reply_token, message)
```

#### StickerSendMessage (Pesan stiker)
```python
message = StickerSendMessage(
    package_id='1',
    sticker_id='1'
)
line_bot_api.reply_message(event.reply_token, message)
```

#### ImagemapSendMessage
```python
message = ImagemapSendMessage(
    base_url='https://example.com/base',
    alt_text='this is an imagemap',
    base_size=BaseSize(height=1040, width=1040),
    actions=[
        URIImagemapAction(
            link_uri='https://example.com/',
            area=ImagemapArea(
                x=0, y=0, width=520, height=1040
            )
        ),
        MessageImagemapAction(
            text='hello',
            area=ImagemapArea(
                x=520, y=0, width=520, height=1040
            )
        )
    ]
)
line_bot_api.reply_message(event.reply_token, message)
```

#### TemplateSendMessage - ButtonsTemplate  (Template)
```python
message = TemplateSendMessage(
    alt_text='Buttons template',
    template=ButtonsTemplate(
        thumbnail_image_url='https://example.com/image.jpg',
        title='Menu',
        text='Please select',
        actions=[
            PostbackTemplateAction(
                label='postback',
                text='postback text',
                data='action=buy&itemid=1'
            ),
            MessageTemplateAction(
                label='message',
                text='message text'
            ),
            URITemplateAction(
                label='uri',
                uri='http://example.com/'
            )
        ]
    )
)
line_bot_api.reply_message(event.reply_token, message)
```

#### TemplateSendMessage - ConfirmTemplate
```python
message = TemplateSendMessage(
    alt_text='Confirm template',
    template=ConfirmTemplate(
        text='Are you sure?',
        actions=[
            PostbackTemplateAction(
                label='postback',
                text='postback text',
                data='action=buy&itemid=1'
            ),
            MessageTemplateAction(
                label='message',
                text='message text'
            )
        ]
    )
)
line_bot_api.reply_message(event.reply_token, message)
```

#### TemplateSendMessage - CarouselTemplate
```python
message = TemplateSendMessage(
    alt_text='Carousel template',
    template=CarouselTemplate(
        columns=[
            CarouselColumn(
                thumbnail_image_url='https://example.com/item1.jpg',
                title='this is menu1',
                text='description1',
                actions=[
                    PostbackTemplateAction(
                        label='postback1',
                        text='postback text1',
                        data='action=buy&itemid=1'
                    ),
                    MessageTemplateAction(
                        label='message1',
                        text='message text1'
                    ),
                    URITemplateAction(
                        label='uri1',
                        uri='http://example.com/1'
                    )
                ]
            ),
            CarouselColumn(
                thumbnail_image_url='https://example.com/item2.jpg',
                title='this is menu2',
                text='description2',
                actions=[
                    PostbackTemplateAction(
                        label='postback2',
                        text='postback text2',
                        data='action=buy&itemid=2'
                    ),
                    MessageTemplateAction(
                        label='message2',
                        text='message text2'
                    ),
                    URITemplateAction(
                        label='uri2',
                        uri='http://example.com/2'
                    )
                ]
            )
        ]
    )
)
line_bot_api.reply_message(event.reply_token, message)
```

#### TemplateSendMessage - ImageCarouselTemplate
```python
message = TemplateSendMessage(
    alt_text='ImageCarousel template',
    template=ImageCarouselTemplate(
        columns=[
            ImageCarouselColumn(
                image_url='https://example.com/item1.jpg',
                action=PostbackTemplateAction(
                    label='postback1',
                    text='postback text1',
                    data='action=buy&itemid=1'
                )
            ),
            ImageCarouselColumn(
                image_url='https://example.com/item2.jpg',
                action=PostbackTemplateAction(
                    label='postback2',
                    text='postback text2',
                    data='action=buy&itemid=2'
                )
            )
        ]
    )
)
line_bot_api.reply_message(event.reply_token, message)
```
# Thanks to
- Arsybai
